// JavaScript source code
function clickResponse()
{this.innerHTML += "Simple click has occured<br>";}

function dblclickResponse()
{this.innerHTML += "Double click has occurred<br>";}

function mouseupResponse()
{this.innerHTML += "Mouse button downwards movement<br>";}

function mousedownResponse()
{this.innerHTML += "Mouse button upwards movement<br>";}

function init() {
	var panel = document.getElementById("panel");
	panel.innerHTML = "Click here on this area &gt;<br>";
	// panel12.innerHTML "Hello World!!!";
	// Eventhandler functions to the panel object:

	window.alert("What is going on?");

	panel.onclick = clickResponse;
	panel.ondblclick = dblclickResponse;
	panel.onmouseup = mouseupResponse;
	panel.onmousedown = mousedownResponse;
}
document.addEventListener("DOMContentLoaded", init, false);