

function init()
{
	var greeting = "Hi ";
	var i = 0;
	for(i=0; i<3; i++)
	{
	    // document.getElementById("panel6").innerHTML = greeting + "<br />";
	    document.getElementById("panel6").innerHTML += greeting + "<br />";
		// window.alert("DOM Loaded");
	}
 /*
	document.getElementById("panel6").innerHTML = greeting + "<br />";
	document.getElementById("panel6").innerHTML = greeting + "<br />";
	document.getElementById("panel6").innerHTML = greeting + "<br />";
*/
}
window.onload = init;	