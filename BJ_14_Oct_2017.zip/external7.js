// JavaScript source code
function display_value(obj) {
    document.getElementById("panel7").innerHTML = "A statement";
    window.alert("Hello World  " + obj);
}

function init()
{
    var a_value = 2;
    display_value(a_value);
}


window.onload = init;