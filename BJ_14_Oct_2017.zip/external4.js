

function init()
{
	var word_hello = "Hello ";	
	var word_world = "World!";
	document.getElementById("panel4").innerHTML = word_hello + word_world;
	window.alert("DOM Loaded");
}
window.onload = init;	