// JavaScript source code
// JavaScript source code
function display_longer_string(stringA, stringB) {
    document.getElementById("panel8").innerHTML = "A string statement";
    var theLongerString = ""
    var nA = stringA.length;
    console.log(nA);
    var nB = stringB.length;

    if (nA > nB)
        {
        theLongerString = stringA;
            window.alert("String A " + stringA);
        }
    else if (nA < nB)
        {
            theLongerString = stringB;
            window.alert("String B " + stringB);
        }
    else
        window.alert("Undetermined");
}

function init() {
    var theAString = "Bodvar";
    var theBString = "Sigfried";
    window.alert("Troubleshooting Alert 1 ");
    display_longer_string(theAString, theBString);
}


window.onload = init;