// JavaScript source code
// Im going to put an advanced function here which will be an object so to speak.

function speed_up(propulsion)
{
	if(propulsion == "wind ")
	{return "<br>Let the wind blow!";}	
	
	if(propulsion == "oars ")
	{return "<br>Row faster!";}	

	else if(propulsion == "steam ")
	{return "<br>More steam!";}

	else if(propulsion == "diesel ")
	{return "<br>Inject more diesel fuel!";}

	else
	{return "<br>Undetermined acceleration method";}
}


function Vessel(name, type, means_of_propulsion, color, people_capacity)
{
	this.name = name;
	this.type = type;
	this.means_of_propulsion = means_of_propulsion;
	this.color = color;
	this.people_capacity = people_capacity;
	this.speed_up = speed_up;
}

function init() {
	var panel11 = document.getElementById("panel11");
	var myShipA = new Vessel("Titanic ", "ocean liner ", "steam ", "black ", "2200 " );
	var propulsion_argument;
	panel11.innerHTML = myShipA.name + myShipA.type + myShipA.means_of_propulsion + myShipA.color + myShipA.people_capacity;
	panel11.innerHTML += myShipA.speed_up(myShipA.means_of_propulsion);
}
document.addEventListener("DOMContentLoaded", init, false);