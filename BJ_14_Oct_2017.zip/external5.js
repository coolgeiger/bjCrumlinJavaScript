

function init()
{
	var three = 3;	
	var four = 4;
	var seven = three + four;
	document.getElementById("panel5").innerHTML = "Three plus four is " + seven;

}
window.onload = init;	