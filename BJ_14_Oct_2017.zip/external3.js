function init()
{
	document.getElementById("panel").innerHTML = "Hello world... from an External JavaScript File!";
}
window.onload = init;	